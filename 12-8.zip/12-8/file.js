document.write("hello full stack ")
document.write("</br>")

document.write("<h1 id='heading'> web development </h1>")

document.write("<ol> <li> tea </li>  <li> coffee </li> </ol>")
document.write("<ul> <li> tea </li>  <li> coffee </li> </ul>")
document.write("<table border='2' style='color:red; width:100%;'> <tr> <td> name</td> <td> qual</td> </tr> <tr> <td> swapna </td> <td> Btech</td> </tr>  <tr> <td> shivani </td> <td> MCA</td> </tr> </table>")